#include "shape.h"
#include "circle.h"
#include <iostream>


void Circle::draw()
{
	std::cout << " you drew a circle " << std::endl;
}