#include "shape.h"
#include "line.h"
#include <iostream>


void Line::draw()
{
	std::cout << " you drew a line " << std::endl;
}