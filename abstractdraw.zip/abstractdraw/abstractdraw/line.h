#ifndef LINE_H
#define LINE_H

class Line : public Shape
{
public:
	void draw() override;
};


#endif // LINE_H
