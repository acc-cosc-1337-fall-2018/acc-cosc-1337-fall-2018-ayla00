#include "shape.h"
#include "line.h"
#include "circle.h"


int main()
{
	Circle circle;
	Line line;

	circle.draw();
	line.draw();

	return 0;
}