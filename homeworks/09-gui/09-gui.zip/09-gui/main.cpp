#include <wx/wx.h>
#include "app.h"

wxIMPLEMENT_APP(App);
