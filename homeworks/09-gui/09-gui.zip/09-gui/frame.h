#ifndef FRAME_H
#define FRAME_H
#include<wx/wx.h>

class Frame : public wxFrame
{
public:
	Frame();
private:
};

#endif // !FRAME_H
