#ifndef PANEL_H
#define PANEL_H
#include<wx/wx.h>
#include<vector>
#include<string>
#include<memory>
#include "text.h"
#include "circle.h"

class Panel : public wxPanel 
{
public:
	Panel(wxWindow* parent);
private:
	void OnDraw(wxCommandEvent& event);
	wxTextCtrl* draw_text;
	wxRadioBox* radio_box;
	void OnMouseDown(wxCommandEvent& event);
	void OnMouseUp(wxCommandEvent& event);
	void draw_shape(Point p, int width, int height, int radius = 25);
	Point coord{ 0,0 };
};

#endif // !PANEL_H
