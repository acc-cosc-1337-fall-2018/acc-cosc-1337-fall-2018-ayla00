#include "panel.h"

Panel::Panel(wxWindow* parent) : wxPanel(parent, -1) 
{
	auto vbox = new wxBoxSizer(wxVERTICAL);
	wxString choices[] {wxT("Text"), wxT("Circle")};
	

	auto hbox0 = new wxBoxSizer(wxHORIZONTAL);
	radio_box = new wxRadioBox(this, -1, wxT("Choices"), wxDefaultPosition, wxDefaultSize,
		                            WXSIZEOF(choices), choices, 1, wxRA_SPECIFY_COLS);

	hbox0->Add(radio_box);

	auto hbox1 = new wxBoxSizer(wxHORIZONTAL);
	auto m_usernameLabel = new wxStaticText(this, wxID_ANY, wxT("Name: "),
		wxDefaultPosition, wxSize(70, -1));
	hbox1->Add(m_usernameLabel, 0);

	draw_text = new wxTextCtrl(this, wxID_ANY);
	hbox1->Add(draw_text, 0);

	//create a button
	auto draw_button = new wxButton(this, -1, wxT("Draw"));
	draw_button->Bind(wxEVT_BUTTON, &Panel::OnDraw, this);

	hbox1->Add(draw_button);

	vbox->Add(hbox0, 0, wxEXPAND | wxLEFT | wxRIGHT | wxTOP, 10);
	vbox->Add(hbox1, 0, wxEXPAND | wxLEFT | wxRIGHT | wxTOP, 10);
	SetSizer(vbox);

	this->Bind(wxEVT_LEFT_DOWN, &Panel::OnMouseDown, this);
	this->Bind(wxEVT_LEFT_UP, &Panel::OnMouseUp, this);
}

void Panel::OnDraw(wxCommandEvent & event)
{
	std::unique_ptr<Shape> shape
		//shape->
		auto cdc = new wxClientDC(this);
	std::unique_ptr<Shape> shape;
	cdc->Clear();
	if (radio_box->GetSelection() == 0) //draw text
	{
		shape = std::make_unique<Text>(cdc, draw_text->GetValue(), ToStdString(), Point(300, 300));
		= std::make_unique<Shape>();
	}
	else if (radio_box->GetSelection() == 1)  // draw circle, look at wt(Cirle)
	{
		shape = std::make_unique<Circle>(cdc, Point(250, 250), 50); //instance of pointer

	}
	else if (radio_box->GetSelection() == 2)
	{
		shape = std::make_unique<acc::Rectangle>(cdc, Point(150, 150), 100, 50);
	}
	shape->draw(); //as long as there is always an instance of shape available

}


void Panel::OnMouseDown(wxCommandEvent & event)
{
	auto cdc = new wxClientDC(this);
	wxPoint position = event.GetPosition();
	int x = cdc->deviceToLogicalX(position.x);
	int y = cdc->deviceToLogicalY(position.y);

	coord.x = x;
	coord.y = y;
}

void Panel::OnMouseUp(wxCommandEvent & event)
{
	draw_shape(coord);
}

void Panel::draw_shape(Point p, int width, int height, int radius = 25) //go to header and give values to widht and height, 10 & 5
{
	auto cdc = new wxClientDC(this);

	std::unique_ptr<Shape> circle = std::make_unique<Circle>(cdc, p, radius);
	circle->draw();
}